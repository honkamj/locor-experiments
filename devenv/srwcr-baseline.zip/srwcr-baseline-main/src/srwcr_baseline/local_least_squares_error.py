"""Local least squares"""

from typing import Sequence

from composable_mapping import MappableTensor
from composable_mapping.util import combine_optional_masks
from torch import Tensor
from torch import abs as torch_abs
from torch import arange
from torch import device as torch_device
from torch import dtype as torch_dtype
from torch import empty, linspace
from torch.autograd import Function
from torch.nn.functional import conv1d, conv_transpose1d

INDEX = 0


def local_least_squares_error(
    source_sampled: MappableTensor,
    target_sampled: MappableTensor,
    stride: int,
    n_bins: int,
) -> Tensor:
    """Compute the local least squares loss between two images.

    Returns:
        The local least squares loss and the local weights if `return_weights` is `True`.
    """
    source_image, source_mask = source_sampled.generate(generate_missing_mask=False)
    target_image, target_mask = target_sampled.generate(generate_missing_mask=False)
    mask = combine_optional_masks(source_mask, target_mask)
    source_probs, _bin_centers_a = _extract_b_spline_features(source_image, n_control_points=n_bins)
    target_probs, bin_centers_b = _extract_b_spline_features(target_image, n_control_points=n_bins)
    bin_centers_b = bin_centers_b[:, None, :]
    if mask is not None:
        source_probs = source_probs * mask
        target_probs = target_probs * mask

    joint_probabilities = joint_regional_density(
        source_probs,
        target_probs,
        stride=stride,
    )
    joint_probabilities = joint_probabilities / joint_probabilities.sum()
    eps = 1e-6
    n_dims = len(source_sampled.spatial_shape)
    prab = joint_probabilities / (joint_probabilities.sum(dim=(1, 2), keepdim=True) + eps)
    pra = prab.sum(dim=2, keepdim=True)
    prb = prab.sum(dim=1, keepdim=True)

    mur = (prb * bin_centers_b).sum(dim=2, keepdim=True)
    sigmar = (prb * bin_centers_b**2).sum(dim=2, keepdim=True) - mur**2

    mur_a = (prab * bin_centers_b).sum(dim=2, keepdim=True) / (pra + eps)
    srwcr = (joint_probabilities * (bin_centers_b**2 - mur_a**2) / (sigmar + eps)).sum(
        dim=tuple(range(1, 3 + n_dims))
    )

    return srwcr


class _JointRegionalDensity(Function):
    """Custom backward implemented to save memory."""

    # pylint: disable=abstract-method,arguments-differ,not-callable
    @staticmethod
    def forward(
        prob_a: Tensor,
        prob_b: Tensor,
        stride: int = 1,
    ):
        n_dims = prob_a.ndim - 2
        kernel_size = stride * 4
        padding = 2 * stride
        kernel = _JointRegionalDensity._build_kernel(
            kernel_size, stride, prob_a.device, prob_a.dtype
        )
        target_spatial_shape = tuple(
            (dim_size - kernel_size + 2 * padding) // stride + 1 for dim_size in prob_a.shape[2:]
        )
        target_volume = empty(
            (
                prob_a.shape[0],
                prob_a.shape[1],
                prob_b.shape[1],
            )
            + target_spatial_shape,
            device=prob_a.device,
            dtype=prob_a.dtype,
        )

        for bin_a_index in range(prob_a.shape[1]):
            product_volume = prob_a[:, bin_a_index : bin_a_index + 1] * prob_b
            target_volume[:, bin_a_index] = _JointRegionalDensity._spatially_separable_conv(
                product_volume, kernel, stride, padding, tuple(range(n_dims))
            )

        return target_volume

    @staticmethod
    def _build_kernel(
        kernel_size: int, stride: int, device: torch_device, dtype: torch_dtype
    ) -> Tensor:
        points = (arange(kernel_size, device=device, dtype=dtype) - (kernel_size - 1) / 2) / stride
        points_abs = torch_abs(points)
        output = (2 / 3 + (0.5 * points_abs - 1) * points_abs**2) * (points_abs < 1)
        output = -((points_abs - 2) ** 3) / 6 * ((points_abs >= 1) & (points_abs < 2)) + output
        return output

    @staticmethod
    def _spatially_separable_conv(
        volume: Tensor,
        kernel_1d: Tensor,
        stride: int,
        padding: int,
        spatial_dims: Sequence[int],
    ) -> Tensor:
        for dim in spatial_dims:
            volume_dim = 2 + dim
            volume = _JointRegionalDensity._conv_1d(
                volume,
                volume_dim,
                kernel_1d,
                stride,
                padding,
            )
        return volume

    @staticmethod
    def _spatially_separable_transposed_conv(
        volume: Tensor,
        kernel_1d: Tensor,
        stride: int,
        padding: int,
        spatial_dims: Sequence[int],
        target_shape: Sequence[int],
    ) -> Tensor:
        for dim in spatial_dims:
            volume_dim = 2 + dim
            volume = _JointRegionalDensity._conv_transposed_1d(
                volume, volume_dim, kernel_1d, stride, padding, target_shape[dim]
            )
        return volume

    @staticmethod
    def _conv_1d(
        volume: Tensor,
        dim: int,
        kernel: Tensor,
        stride: int,
        padding: int,
    ) -> Tensor:
        dim_size = volume.size(dim)
        volume = volume.movedim(dim, -1)
        dim_excluded_shape = volume.shape[:-1]
        volume = volume.reshape(-1, 1, dim_size)
        convolved = conv1d(volume, kernel[None, None], bias=None, stride=stride, padding=padding)
        return convolved.reshape(dim_excluded_shape + (-1,)).movedim(-1, dim)

    @staticmethod
    def _conv_transposed_1d(
        volume: Tensor,
        dim: int,
        kernel: Tensor,
        stride: int,
        padding: int,
        target_dim_size: int,
    ) -> Tensor:
        dim_size = volume.size(dim)
        volume = volume.movedim(dim, -1)
        dim_excluded_shape = volume.shape[:-1]
        volume = volume.reshape(-1, 1, dim_size)
        output_padding = target_dim_size - ((dim_size - 1) * stride + kernel.size(0) - 2 * padding)
        convolved = conv_transpose1d(
            volume,
            kernel[None, None],
            bias=None,
            stride=stride,
            padding=padding,
            output_padding=output_padding,
        )
        return convolved.reshape(dim_excluded_shape + (-1,)).movedim(-1, dim)

    @staticmethod
    def setup_context(ctx, inputs, output):
        (
            prob_a_grad_needed,
            prob_b_grad_needed,
            _,
        ) = ctx.needs_input_grad
        (
            _prob_a,
            prob_b,
            stride,
        ) = inputs
        ctx.stride = stride
        if prob_b_grad_needed:
            raise NotImplementedError("Gradient w.r.t. prob_b is not implemented.")
        if prob_a_grad_needed:
            ctx.save_for_backward(prob_b)

    @staticmethod
    def backward(ctx, grad_output):
        (
            prob_a_grad_needed,
            _,
            _,
        ) = ctx.needs_input_grad
        if not prob_a_grad_needed:
            return None, None, None, None
        (prob_b,) = ctx.saved_tensors
        n_dims = prob_b.ndim - 2
        kernel_size = ctx.stride * 4
        padding = 2 * ctx.stride
        kernel = _JointRegionalDensity._build_kernel(
            kernel_size, ctx.stride, grad_output.device, grad_output.dtype
        )
        original_spatial_shape = prob_b.shape[2:]
        target_prob_a_grad = empty(
            grad_output.shape[:2] + original_spatial_shape,
            device=grad_output.device,
            dtype=grad_output.dtype,
        )
        for bin_a_index in range(grad_output.shape[1]):
            grad_output_bin_a = grad_output[:, bin_a_index]
            target_prob_a_grad[:, bin_a_index] = (
                _JointRegionalDensity._spatially_separable_transposed_conv(
                    grad_output_bin_a,
                    kernel,
                    ctx.stride,
                    padding,
                    tuple(range(n_dims)),
                    original_spatial_shape,
                )
                * prob_b
            ).sum(dim=1)
        return target_prob_a_grad, None, None, None


def joint_regional_density(prob_a: Tensor, prob_b: Tensor, stride: int = 1):
    """Compute the joint regional densities of two probability volumes."""
    return _JointRegionalDensity.apply(prob_a, prob_b, stride)


def _extract_b_spline_features(
    volume: Tensor,
    n_control_points: int,
    control_point_padding: int = 0,
) -> tuple[Tensor, Tensor]:
    min_value = volume.detach().amin()
    max_value = volume.detach().amax()
    spatial_shape = volume.shape[2:]
    if n_control_points - 1 - 2 * control_point_padding <= 0:
        raise ValueError("Not enough control points")
    spacing = (max_value - min_value) / (n_control_points - 1 - 2 * control_point_padding)
    min_control_point = min_value - control_point_padding * spacing
    max_control_point = max_value + control_point_padding * spacing
    unit_range = linspace(0, 1, n_control_points, device=volume.device)
    spline_centers = (min_control_point + (max_control_point - min_control_point) * unit_range)[
        (
            None,
            ...,
        )
        + (None,) * len(spatial_shape)
    ]
    spline_features = _parzen_window((volume - spline_centers) / spacing)
    return spline_features, spline_centers


def _parzen_window(points: Tensor) -> Tensor:
    abs_points = points.abs()
    return (-1.8 * abs_points**2 - 0.1 * abs_points + 1) * (abs_points < 0.5) + (
        1.8 * abs_points**2 - 3.7 * abs_points + 1.9
    ) * ((abs_points >= 0.5) & (abs_points < 1))
