# SRWCR baseline

Implementation of the SRWCR algorithm for the Locor paper (https://github.com/honkamj/locor-experiments).

Gong, Lun, et al. "Nonrigid image registration using spatially region-weighted correlation ratio and GPU-acceleration." IEEE journal of biomedical and health informatics 23.2 (2018): 766-778.