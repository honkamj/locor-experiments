"""Local correlation ratio"""

from composable_mapping import (
    CoordinateSystem,
    GridComposableMapping,
    ISampler,
    samplable_volume,
)
from torch import Tensor, cat, linspace


def local_correlation_ratio(
    source: GridComposableMapping,
    target: GridComposableMapping,
    sampler: ISampler,
    coordinates: CoordinateSystem,
    n_control_points: int,
    eps: float = 1e-5,
) -> Tensor:
    """Compute the local least squares loss between two images.

    Args:
        source_image: The source image.
        target_image: The target image.
        fitting_grid: Defines the points at which the local least squares is fitted.
        mask: The mask to apply to the images.

    Returns:
        The local least squares loss and the local weights if `return_weights` is `True`.
    """
    source_image, source_mask = source.sample().generate(generate_missing_mask=True, cast_mask=True)
    target_image, target_mask = target.sample().generate(generate_missing_mask=True, cast_mask=True)
    mask = source_mask * target_mask

    window_masks = _extract_b_spline_features(
        source_image,
        n_control_points=n_control_points,
        control_point_padding=0,
        min_value=source_image.amin().detach(),
        max_value=source_image.amax().detach(),
    )
    target_image = target_image * mask
    window_masks = window_masks * mask

    windowed_target_image = window_masks * target_image
    windowed_target_image_squared = window_masks * target_image**2
    moving_averages = (
        samplable_volume(
            cat(
                (
                    windowed_target_image,
                    windowed_target_image_squared,
                    target_image,
                    target_image**2,
                    mask,
                    window_masks,
                ),
                dim=1,
            ),
            coordinate_system=source.coordinate_system,
            sampler=sampler,
        )
        .sample_to(coordinates)
        .generate_values()
    )

    (
        windowed_target_image_avg,
        windowed_target_image_squared_avg,
        target_image_avg,
        target_image_avg_squared,
        mask_avg,
        window_masks_avg,
    ) = moving_averages.split(
        [
            n_control_points,
            n_control_points,
            1,
            1,
            1,
            n_control_points,
        ],
        dim=1,
    )

    target_variance = target_image_avg_squared - target_image_avg**2 / (mask_avg + eps)

    windowed_target_variance = windowed_target_image_squared_avg - windowed_target_image_avg**2 / (
        window_masks_avg + eps
    )

    return windowed_target_variance.sum(dim=1, keepdim=True) / (target_variance + eps)


def _extract_b_spline_features(
    volume: Tensor,
    n_control_points: int,
    min_value: Tensor,
    max_value: Tensor,
    control_point_padding: int = 0,
) -> Tensor:
    spatial_shape = volume.shape[2:]
    if n_control_points - 1 - 2 * control_point_padding <= 0:
        raise ValueError("Not enough control points")
    spacing = (max_value - min_value) / (n_control_points - 1 - 2 * control_point_padding)
    min_control_point = min_value - control_point_padding * spacing
    max_control_point = max_value + control_point_padding * spacing
    unit_range = linspace(0, 1, n_control_points, device=volume.device)
    spline_centers = (min_control_point + (max_control_point - min_control_point) * unit_range)[
        (
            None,
            ...,
        )
        + (None,) * len(spatial_shape)
    ]
    spline_features = _parzen_window((volume - spline_centers) / spacing)
    spline_features = spline_features / spline_features.sum(dim=1, keepdim=True)
    return spline_features


def _parzen_window(points: Tensor) -> Tensor:
    abs_points = points.abs()
    return (-1.8 * abs_points**2 - 0.1 * abs_points + 1) * (abs_points < 0.5) + (
        1.8 * abs_points**2 - 3.7 * abs_points + 1.9
    ) * ((abs_points >= 0.5) & (abs_points < 1))
