"""MIND SSC loss"""

import numpy as np
import torch
from composable_mapping import MappableTensor
from torch import Tensor, nn
from torch.nn import functional as F


class MINDSSCLoss(nn.Module):
    """MIND SSC loss function

    Copied from
    https://github.com/junyuchen245/TransMorph_Transformer_for_Medical_Image_Registration
    """

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._features_true: Tensor | None = None

    def _pdist_squared(self, x):
        x_squared = (x**2).sum(dim=1).unsqueeze(2)
        y_squared = x_squared.permute(0, 2, 1)
        dist = x_squared + y_squared - 2.0 * torch.bmm(x.permute(0, 2, 1), x)
        dist[dist != dist] = 0
        dist = torch.clamp(dist, 0.0, np.inf)
        return dist

    def _compute_features(self, img, radius=2, dilation=2):
        # see http://mpheinrich.de/pub/miccai2013_943_mheinrich.pdf for details
        # on the MIND-SSC descriptor
        device = img.device
        # kernel size
        kernel_size = radius * 2 + 1

        # define start and end locations for self-similarity pattern
        six_neighbourhood = torch.tensor(
            [[0, 1, 1], [1, 1, 0], [1, 0, 1], [1, 1, 2], [2, 1, 1], [1, 2, 1]], dtype=torch.long
        )

        # squared distances
        dist = self._pdist_squared(six_neighbourhood.t().unsqueeze(0)).squeeze(0)

        # define comparison mask
        x, y = torch.meshgrid(torch.arange(6), torch.arange(6))
        mask = (x > y).view(-1) & (dist == 2).view(-1)

        # build kernel
        idx_shift1 = six_neighbourhood.unsqueeze(1).repeat(1, 6, 1).view(-1, 3)[mask, :]
        idx_shift2 = six_neighbourhood.unsqueeze(0).repeat(6, 1, 1).view(-1, 3)[mask, :]
        mshift1 = torch.zeros(12, 1, 3, 3, 3, device=device)
        mshift1.view(-1)[
            torch.arange(12) * 27 + idx_shift1[:, 0] * 9 + idx_shift1[:, 1] * 3 + idx_shift1[:, 2]
        ] = 1
        mshift2 = torch.zeros(12, 1, 3, 3, 3, device=device)
        mshift2.view(-1)[
            torch.arange(12) * 27 + idx_shift2[:, 0] * 9 + idx_shift2[:, 1] * 3 + idx_shift2[:, 2]
        ] = 1
        rpad1 = nn.ReplicationPad3d(dilation)
        rpad2 = nn.ReplicationPad3d(radius)

        # compute patch-ssd
        ssd = F.avg_pool3d(  # pylint: disable=not-callable
            rpad2(
                (
                    F.conv3d(rpad1(img), mshift1, dilation=dilation)  # pylint: disable=not-callable
                    - F.conv3d(  # pylint: disable=not-callable
                        rpad1(img), mshift2, dilation=dilation
                    )
                )
                ** 2
            ),
            kernel_size,
            stride=1,
        )

        # MIND equation
        mind = ssd - torch.min(ssd, 1, keepdim=True)[0]
        mind_var = torch.mean(mind, 1, keepdim=True)
        mind_var = torch.clamp(
            mind_var, (mind_var.mean() * 0.001).item(), (mind_var.mean() * 1000).item()
        )
        mind = mind / mind_var
        mind = torch.exp(-mind)

        # permute to have same ordering as C++ code
        mind = mind[
            :, torch.tensor([6, 8, 1, 11, 2, 10, 0, 7, 9, 4, 5, 3], dtype=torch.long), :, :, :
        ]

        return mind

    def forward(self, y_pred: MappableTensor, y_true: MappableTensor):
        """Compute MIND loss."""
        y_pred_values, y_pred_mask = y_pred.generate(generate_missing_mask=True, cast_mask=True)
        y_true_values, y_true_mask = y_true.generate(generate_missing_mask=True, cast_mask=True)
        mask = y_pred_mask * y_true_mask
        y_pred_values = y_pred_values * mask
        y_true_values = y_true_values * mask
        features_pred = self._compute_features(y_pred_values)
        features_true = (
            self._features_true
            if self._features_true is not None
            else self._compute_features(y_true_values)
        )
        return torch.mean(mask * (features_pred - features_true) ** 2)
