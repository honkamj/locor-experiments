"""Uniform smoothing sampler."""

from typing import Sequence, Union

from composable_mapping import (
    BaseSeparableSampler,
    ISeparableKernelSupport,
    LimitDirection,
)
from torch import Tensor, ones_like


class _NonInclusiveKernelSupport(ISeparableKernelSupport):
    def __init__(self, truncate_at: int | float) -> None:
        self._truncate_at = truncate_at

    def __call__(self, limit_direction: LimitDirection) -> tuple[float, float, bool, bool]:
        return -self._truncate_at, self._truncate_at, False, False

    def derivative(self) -> "ISeparableKernelSupport":
        raise NotImplementedError


class UniformSampler(BaseSeparableSampler):
    """Interpolation with uniform kernel."""

    def __init__(
        self,
        truncate_at: Sequence[int | float],
        mean: Sequence[int | float] | None = None,
        radius: Sequence[int | float] | None = None,
        extrapolation_mode: str = "zeros",
        mask_extrapolated_regions: bool = False,
        convolution_threshold: float = 1e-3,
        mask_threshold: float = 1e-5,
    ) -> None:
        self._mean = mean
        self._radius = radius
        self._truncate_at = truncate_at
        super().__init__(
            extrapolation_mode=extrapolation_mode,
            convolution_threshold=convolution_threshold,
            mask_extrapolated_regions=mask_extrapolated_regions,
            mask_threshold=mask_threshold,
            limit_direction=LimitDirection.left(),
        )

    def _kernel_support(self, spatial_dim: int) -> _NonInclusiveKernelSupport:
        return _NonInclusiveKernelSupport(self._truncate_at[spatial_dim])

    def _is_interpolating_kernel(self, spatial_dim: int) -> bool:
        return False

    def _left_limit_kernel(self, coordinates: Tensor, spatial_dim: int) -> Tensor:
        raise NotImplementedError

    def _right_limit_kernel(self, coordinates: Tensor, spatial_dim: int) -> Tensor:
        radius: Union[Tensor, float] = 1.0 if self._radius is None else self._radius[spatial_dim]
        mean: Union[Tensor, float] = 0.0 if self._mean is None else self._mean[spatial_dim]
        diff = coordinates - mean
        kernel = ones_like(coordinates) * ((diff >= -radius) & (diff <= radius))
        kernel = kernel / kernel.sum()
        return kernel

    def sample_values(
        self,
        volume: Tensor,
        coordinates: Tensor,
    ) -> Tensor:
        raise NotImplementedError

    def sample_mask(
        self,
        mask: Tensor,
        coordinates: Tensor,
    ) -> Tensor:
        raise NotImplementedError
