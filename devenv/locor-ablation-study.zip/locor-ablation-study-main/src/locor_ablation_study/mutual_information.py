"""Differentiable mutual information loss"""

from typing import Any, Mapping

from composable_mapping import MappableTensor
from numpy import quantile
from torch import Tensor, linspace, matmul


class MutualInformationLoss:
    """Differentiable global mutual information via Parzen windowing method.

    Guo, Courtney K. Multi-modal image registration with unsupervised deep
    learning. Diss. Massachusetts Institute of Technology, 2019.

    Rewritten from https://github.com/DeepRegNet/DeepReg

    The inputs are clipped to range [0, 1] after applying shift and normalization.
    """

    def __init__(
        self,
        num_bins: int | None = 23,
        sigma_ratio: float | None = 0.5,
        epsilon: float | None = 1e-5,
        min_quantile: float | None = 0.0,
        max_quantile: float | None = 1.0,
    ) -> None:
        self._params: Mapping[str, Any] = {
            "num_bins": num_bins,
            "sigma_ratio": sigma_ratio,
            "epsilon": epsilon,
            "min_quantile": min_quantile,
            "max_quantile": max_quantile,
        }
        self._volume_1_min: float | None = None
        self._volume_2_min: float | None = None
        self._volume_1_max: float | None = None
        self._volume_2_max: float | None = None

    def _pre_process(
        self,
        volume_1: Tensor,
        mask_1: Tensor,
        volume_2: Tensor,
        mask_2: Tensor,
    ) -> tuple[Tensor, Tensor]:
        if (
            self._volume_1_min is None
            or self._volume_2_min is None
            or self._volume_1_max is None
            or self._volume_2_max is None
        ):
            valid_voxels_1 = volume_1.detach()[0][mask_1[0].broadcast_to(volume_1.shape[1:])]
            valid_voxels_2 = volume_2.detach()[0][mask_2[0].broadcast_to(volume_2.shape[1:])]
            self._volume_1_min = float(
                quantile(valid_voxels_1.numpy(force=True), self._params["min_quantile"])
            )
            self._volume_2_min = float(
                quantile(valid_voxels_2.numpy(force=True), self._params["min_quantile"])
            )
            self._volume_1_max = float(
                quantile(valid_voxels_1.numpy(force=True), self._params["max_quantile"])
            )
            self._volume_2_max = float(
                quantile(valid_voxels_2.numpy(force=True), self._params["max_quantile"])
            )
        return (
            ((volume_1 - self._volume_1_min) / (self._volume_1_max - self._volume_1_min)).clamp(
                0.0, 1.0
            ),
            ((volume_2 - self._volume_2_min) / (self._volume_2_max - self._volume_2_min)).clamp(
                0.0, 1.0
            ),
        )

    def __call__(
        self,
        image_1: MappableTensor,
        image_2: MappableTensor,
    ) -> Tensor:
        volume_1, mask_1 = image_1.generate()
        volume_2, mask_2 = image_2.generate()
        volume_1, volume_2 = self._pre_process(volume_1, mask_1, volume_2, mask_2)
        mask = mask_1 * mask_2
        volume_1 = volume_1 * mask
        volume_2 = volume_2 * mask
        dtype = volume_1.dtype
        device = volume_1.device
        batch_size = volume_1.size(0)

        bin_centers = linspace(0.0, 1.0, self._params["num_bins"], dtype=dtype, device=device)
        sigma = (bin_centers[1:] - bin_centers[:-1]).mean() * self._params["sigma_ratio"]
        preterm = 1 / (2 * sigma.square())
        volume_1 = volume_1.reshape(batch_size, -1, 1)
        volume_2 = volume_2.reshape(batch_size, -1, 1)
        n_values = float(volume_1.size(1))

        voxel_densities_1, marginal_density_1 = self._compute_densities(
            volume_1, bin_centers=bin_centers, preterm=preterm
        )
        voxel_densities_2, marginal_density_2 = self._compute_densities(
            volume_2, bin_centers=bin_centers, preterm=preterm
        )

        product_density = matmul(marginal_density_1[..., None], marginal_density_2[..., None, :])
        joint_density = matmul(voxel_densities_1.transpose(1, 2), voxel_densities_2) / n_values

        density_ratio = (joint_density + self._params["epsilon"]) / (
            product_density + self._params["epsilon"]
        )
        return (
            -(joint_density * (density_ratio + self._params["epsilon"]).log())
            .sum(dim=(1, 2))
            .mean()
        )

    @staticmethod
    def _compute_densities(
        volume: Tensor, bin_centers: Tensor, preterm: Tensor
    ) -> tuple[Tensor, Tensor]:
        volume = volume.view(volume.size(0), -1, 1)
        voxel_densities_unnormalized = (
            -preterm * (volume - bin_centers[None, None]).square()
        ).exp()
        voxel_densities = voxel_densities_unnormalized / voxel_densities_unnormalized.sum(
            dim=-1, keepdim=True
        )
        marginal_density = voxel_densities.mean(1)
        return voxel_densities, marginal_density
