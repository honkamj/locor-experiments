# Locor ablation study

Implementation for the ablation study in the Locor paper (https://github.com/honkamj/locor-experiments).